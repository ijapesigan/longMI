library(testthat)
library(longMI)

test_check("longMI")
